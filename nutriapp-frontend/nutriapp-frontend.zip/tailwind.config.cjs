module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        'food-green': '#2f855a',
        'food-green-2': '#38a169',
        'food-orange': '#dd6b20',
        'food-yellow': '#d69e2e',
      },
      borderRadius: {
        'xl-2': '1rem',
      },
      boxShadow: {
        glass: '0 6px 18px rgba(16,24,40,0.08)',
      },
    },
  },
  plugins: [],
}
