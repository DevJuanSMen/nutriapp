import React, { useState, useEffect } from 'react'
import Card from '../components/Card'
import Button from '../components/Button'
import defaultRecipes from '../data/recipes'

const STORAGE_KEY = 'nutriapp:recipes'

export default function Recipes() {
  const [recipes, setRecipes] = useState(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY)
      return raw ? JSON.parse(raw) : defaultRecipes
    } catch {
      return defaultRecipes
    }
  })

  const [form, setForm] = useState({ name: '', ingredients: '', calories: '', image: '', instructions: '' })
  const [selected, setSelected] = useState(null)
  const [openForm, setOpenForm] = useState(false)

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(recipes))
    } catch (e) {
      console.error(e)
    }
  }, [recipes])

  function addRecipe() {
    if (!form.name || !form.calories) return
    const newR = {
      id: Date.now(),
      name: form.name,
      ingredients: form.ingredients ? form.ingredients.split(',').map((s) => s.trim()) : [],
      calories: Number(form.calories),
      image: form.image || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=80',
      instructions: form.instructions || '',
    }
    setRecipes([newR, ...recipes])
    setForm({ name: '', ingredients: '', calories: '', image: '', instructions: '' })
  }


  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Recetario</h2>
        <Button onClick={() => setOpenForm(true)}>Agregar receta</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {recipes.map((r) => (
          <div key={r.id}>
            <Card title={r.name} headerImage={r.image}>
              <div className="text-sm text-gray-600">Ingredientes: {r.ingredients.join(', ')}</div>
              <div className="mt-2 font-semibold">{r.calories} kcal</div>
              <div className="mt-3 flex gap-2">
                <Button onClick={() => setSelected(r)} className="text-sm">Ver detalle</Button>
              </div>
            </Card>
          </div>
        ))}
      </div>

      {selected && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="w-full max-w-2xl p-4">
            <Card title={selected.name} headerImage={selected.image}>
              <div className="text-sm text-gray-700">Ingredientes: {selected.ingredients.join(', ')}</div>
              <div className="mt-2">Calorías: <strong>{selected.calories} kcal</strong></div>
              {selected.instructions && (
                <div className="mt-4">
                  <h4 className="font-semibold">Preparación</h4>
                  <p className="text-sm text-gray-700">{selected.instructions}</p>
                </div>
              )}
              <div className="mt-4 flex justify-end gap-2">
                <Button onClick={() => setSelected(null)} variant="accent">Cerrar</Button>
              </div>
            </Card>
          </div>
        </div>
      )}

      {openForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="w-full max-w-2xl p-4">
            <Card title="Agregar nueva receta">
              <div className="space-y-2">
                <input className="w-full p-2 border rounded" placeholder="Nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <input className="w-full p-2 border rounded" placeholder="Ingredientes (separados por coma)" value={form.ingredients} onChange={(e) => setForm({ ...form, ingredients: e.target.value })} />
                <input className="w-full p-2 border rounded" placeholder="Calorías" type="number" value={form.calories} onChange={(e) => setForm({ ...form, calories: e.target.value })} />
                <input className="w-full p-2 border rounded" placeholder="URL imagen (opcional)" value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} />
                <textarea className="w-full p-2 border rounded" placeholder="Instrucciones (opcional)" value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} />
                <div className="flex gap-2 justify-end">
                  <Button onClick={() => { addRecipe(); setOpenForm(false); }}>Guardar receta</Button>
                  <Button onClick={() => setOpenForm(false)} variant="accent">Cancelar</Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
