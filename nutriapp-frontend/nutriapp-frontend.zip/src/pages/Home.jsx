import React, { useState, useEffect } from 'react'
import useLocalStorage from '../hooks/useLocalStorage'
import Card from '../components/Card'
import Button from '../components/Button'
import { bmi, recommendedCalories, classificationByTarget } from '../utils/nutrition'
import api from '../services/api'
import { useNavigate } from 'react-router-dom'

function bmiCategory(imc) {
  if (imc < 18.5) return 'Bajo peso'
  if (imc < 25) return 'Normal'
  if (imc < 30) return 'Sobrepeso'
  return 'Obesidad'
}

function classificationLabel(total, target) {
  if (!target) return 'Sin objetivo definido'
  if (total < target * 0.9) return 'Déficit calórico (por debajo de la meta)'
  if (total <= target * 1.1) return 'En rango saludable'
  return 'Exceso calórico (por encima de la meta)'
}

function DonutChart({ total, target }) {
  const size = 160
  const stroke = 22
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const rawPercent = target ? (total / target) * 100 : 0
  const displayPercent = Math.round(rawPercent)
  // For stroke, clamp to a reasonable max so it doesn't overflow visually
  const strokePercent = Math.min(Math.max(rawPercent, 0), 200)
  const offset = circumference - (strokePercent / 100) * circumference

  // color scale based on rawPercent
  let color = '#68D391' // green
  if (rawPercent > 140) color = '#e53e3e'
  else if (rawPercent > 120) color = '#dd6b20'
  else if (rawPercent > 100) color = '#d69e2e'

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <g transform={`translate(${size / 2}, ${size / 2})`}>
          <circle r={radius} fill="none" stroke="#edf2f7" strokeWidth={stroke} />
          <circle r={radius} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round" transform={`rotate(-90)`} />
          <text x="0" y="4" textAnchor="middle" fontSize="16" fontWeight="700">{total}</text>
          <text x="0" y="22" textAnchor="middle" fontSize="11" fill="#4a5568">kcal</text>
        </g>
      </svg>
      <div className="mt-2 text-sm text-center">
        <div><strong>{displayPercent}%</strong> del objetivo</div>
        <div className="muted text-xs">{classificationLabel(total, target)}</div>
      </div>
    </div>
  )
}

export default function Home() {
  const [items, setItems] = useState([])
  const [profile, setProfile] = useState(null)
  const [editingProfile, setEditingProfile] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    let mounted = true
    async function load() {
      const token = localStorage.getItem('token')
      if (!token) {
        navigate('/login')
        return
      }

      try {
        // Load profile
        const { data: profileData } = await api.get('/profile')
        if (mounted && profileData) {
          // Normalize if needed, but backend should return correct structure
          setProfile(profileData)
        }

        // Load meals
        const { data: mealsData } = await api.get('/meals')
        if (mounted && mealsData) setItems(mealsData)
      } catch (err) {
        console.error('Error loading data:', err)
        if (err.response?.status === 401 || err.response?.status === 403) {
          navigate('/login')
        }
      }
    }
    load()

    const handler = () => {
      load()
    }
    window.addEventListener('meals:updated', handler)
    return () => { mounted = false; window.removeEventListener('meals:updated', handler) }
  }, [navigate])

  const total = items.reduce((s, i) => s + Number(i.calories || 0), 0)
  const weightKg = profile ? (profile.weight_kg ?? profile.weightKg ?? profile.weight) : null
  const heightCm = profile ? (profile.height_cm ?? profile.heightCm ?? profile.height) : null
  const imc = profile ? bmi(weightKg, heightCm) : null
  const target = profile ? recommendedCalories({ sex: profile.sex_assigned ?? profile.sex, weightKg: weightKg, heightCm: heightCm, age: profile.age }) : null
  const classification = classificationByTarget(total, target)

  async function saveProfile(e) {
    e.preventDefault()
    try {
      const payload = {
        age: profile?.age ?? null,
        weight_kg: profile?.weightKg ?? profile?.weight_kg ?? null,
        height_cm: profile?.heightCm ?? profile?.height_cm ?? null,
        sex_assigned: profile?.sex ?? profile?.sex_assigned ?? null,
        activity_level: profile?.activity ?? profile?.activity_level ?? null,
      }

      const { data: saved } = await api.put('/profile', payload)
      setProfile(saved)
      setEditingProfile(false)
    } catch (err) {
      console.error(err)
      alert('Error al guardar el perfil')
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card title="Perfil">
          <div className="space-y-2">
            {profile ? (
              <>
                <div className="text-sm">Edad: <strong>{profile.age ?? '--'}</strong></div>
                <div className="text-sm">Altura: <strong>{profile.height_cm ?? profile.heightCm ?? '--'} cm</strong></div>
                <div className="text-sm">Peso: <strong>{profile.weight_kg ?? profile.weightKg ?? '--'} kg</strong></div>
                <div className="text-sm">Género (sexo asignado): <strong>{profile.sex_assigned ?? profile.sex ?? '--'}</strong></div>
                <div className="text-sm">Nivel actividad: <strong>{profile.activity_level ?? profile.activity ?? '--'}</strong></div>
                <div className="text-sm">IMC: <strong>{imc ?? '--'}</strong> <span className="muted">{imc ? bmiCategory(imc) : ''}</span></div>
                <div className="text-sm">Objetivo calórico: <strong>{target ?? '--'} kcal</strong></div>
              </>
            ) : (
              <div className="muted">Aún no configuraste tu perfil. Pulsa "Editar perfil" para completar tus datos.</div>
            )}
            <div className="mt-2 flex gap-2">
              <Button onClick={() => { if (!profile) setProfile({}); setEditingProfile(true); }}>Editar perfil</Button>
            </div>
          </div>
        </Card>

        <Card title="Métricas de hoy">
          {items.length === 0 ? (
            <div className="p-4">
              <p className="muted">Aún no has registrado comidas. Ve a Registro para añadir tu primera comida.</p>
              <div className="mt-3">
                <Button onClick={() => navigate('/calories')}>Ir a Registro</Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <DonutChart total={total} target={target} />
              <div>
                <div className="text-lg font-semibold">{classification.label}</div>
                <div className="muted">Meta: {target ?? '--'} kcal</div>
                <div className="mt-2">Total: <strong>{total} kcal</strong></div>
              </div>
            </div>
          )}
        </Card>

        <Card title="Acciones">
          <div className="flex flex-col gap-2">
            <Button onClick={() => window.location.href = '/calories'}>Ir a Registro</Button>
            <Button onClick={() => window.location.href = '/recipes'} variant="accent">Ir a Recetario</Button>
            <div className="muted text-sm">Consejo: registra tus comidas para ver cómo evolucionas respecto a tu objetivo.</div>
          </div>
        </Card>
      </div>

      <Card title="Distribución de calorías">
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
          <div className="flex items-center justify-center">
            <DonutChart total={total} target={target} />
          </div>

          <div>
            <h4 className="font-semibold mb-2">Contribución por comida</h4>
            {items.length === 0 && <p className="muted">No hay comidas registradas.</p>}
            {items.map((it) => {
              const pct = target ? Math.round((it.calories / target) * 100) : 0
              return (
                <div key={it.id} className="mb-3">
                  <div className="flex justify-between text-sm">
                    <div className="font-medium">{it.name}</div>
                    <div className="muted">{it.calories} kcal ({pct}%)</div>
                  </div>
                  <div className="w-full h-2 bg-gray-200 rounded mt-1 overflow-hidden">
                    <div style={{ width: `${Math.min(100, pct)}%`, background: pct > 120 ? '#e53e3e' : pct > 100 ? '#dd6b20' : '#68D391', height: '100%' }}></div>
                  </div>
                </div>
              )
            })}

            <div className="mt-4">
              <h4 className="font-semibold">Recomendación</h4>
              {(!target || target === null) && <p className="muted">Define tu perfil para obtener recomendaciones personalizadas.</p>}
              {target && total < target * 0.9 && <p>Estás en déficit. Considera añadir un snack nutritivo para alcanzar tus necesidades.</p>}
              {target && total <= target * 1.1 && <p>Estás en el rango. Mantén tu patrón alimentario balanceado y controla porciones.</p>}
              {target && total > target * 1.1 && <p>Exceso de calorías. Revisa porciones y elige opciones más bajas en energía.</p>}
            </div>
          </div>
        </div>
      </Card>

      {editingProfile && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="w-full max-w-md p-4">
            <Card title="Editar perfil">
              <form onSubmit={saveProfile} className="space-y-2">
                <input
                  className="w-full p-2 border rounded"
                  placeholder="Edad"
                  type="number"
                  value={profile?.age ?? ''}
                  onChange={(e) => setProfile(prev => ({ ...(prev || {}), age: e.target.value === '' ? null : Number(e.target.value) }))}
                />
                <input
                  className="w-full p-2 border rounded"
                  placeholder="Peso kg"
                  type="number"
                  value={profile?.weightKg ?? profile?.weight_kg ?? ''}
                  onChange={(e) => setProfile(prev => ({ ...(prev || {}), weightKg: e.target.value === '' ? null : Number(e.target.value) }))}
                />
                <input
                  className="w-full p-2 border rounded"
                  placeholder="Altura cm"
                  type="number"
                  value={profile?.heightCm ?? profile?.height_cm ?? ''}
                  onChange={(e) => setProfile(prev => ({ ...(prev || {}), heightCm: e.target.value === '' ? null : Number(e.target.value) }))}
                />
                <select
                  value={profile?.sex ?? profile?.sex_assigned ?? ''}
                  onChange={(e) => setProfile(prev => ({ ...(prev || {}), sex: e.target.value }))}
                  className="w-full p-2 border rounded"
                >
                  <option value="">Selecciona sexo</option>
                  <option value="male">Masculino (sexo asignado al nacer)</option>
                  <option value="female">Femenino (sexo asignado al nacer)</option>
                </select>
                <select
                  value={profile?.activity ?? profile?.activity_level ?? ''}
                  onChange={(e) => setProfile(prev => ({ ...(prev || {}), activity: e.target.value }))}
                  className="w-full p-2 border rounded"
                >
                  <option value="">Selecciona nivel de actividad</option>
                  <option value="sedentary">Sedentario</option>
                  <option value="light">Ligera</option>
                  <option value="moderate">Moderada</option>
                  <option value="active">Activa</option>
                  <option value="very">Muy activa</option>
                </select>
                <div className="flex gap-2 justify-end">
                  <Button type="submit">Guardar</Button>
                  <Button onClick={() => setEditingProfile(false)} variant="accent">Cancelar</Button>
                </div>
              </form>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
