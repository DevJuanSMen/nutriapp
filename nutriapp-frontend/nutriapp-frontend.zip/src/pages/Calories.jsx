import React, { useState, useEffect } from 'react'
import useLocalStorage from '../hooks/useLocalStorage'
import Card from '../components/Card'
import Button from '../components/Button'
import api from '../services/api'

export default function Calories() {
  const [items, setItems] = useLocalStorage('nutriapp:meals', [])
  const [name, setName] = useState('')
  const [calories, setCalories] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        const token = localStorage.getItem('token')
        if (!token) return
        const { data } = await api.get('/meals')
        if (mounted) setItems(data)
      } catch (e) {
        console.error(e)
      }
    }
    load()
    return () => { mounted = false }
  }, [])

  async function fetchMeals() {
    try {
      const { data } = await api.get('/meals')
      setItems(data ?? [])
    } catch (err) {
      console.error('Error fetching meals:', err)
    }
  }

  const total = items.reduce((s, i) => s + Number(i.calories || 0), 0)

  async function add() {
    if (!name || !calories) return
    setLoading(true)

    try {
      const token = localStorage.getItem('token')
      if (token) {
        await api.post('/meals', { name, calories: Number(calories) })
        await fetchMeals()
        try { window.dispatchEvent(new CustomEvent('meals:updated')) } catch (e) { }
      } else {
        // Fallback for non-authenticated (though protected route should prevent this)
        const next = [...items, { id: Date.now(), name, calories: Number(calories) }]
        setItems(next)
      }
    } catch (err) {
      console.error('Error inserting meal:', err)
      alert('Error al guardar la comida')
    } finally {
      setLoading(false)
      setName('')
      setCalories('')
    }
  }

  async function remove(id) {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        await api.delete(`/meals/${id}`)
        await fetchMeals()
        try { window.dispatchEvent(new CustomEvent('meals:updated')) } catch (e) { }
      } else {
        setItems(items.filter((i) => i.id !== id))
      }
    } catch (err) {
      console.error('Error deleting meal:', err)
    }
  }

  async function resetDay() {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        await api.delete('/meals')
        setItems([])
        try { window.dispatchEvent(new CustomEvent('meals:updated')) } catch (e) { }
      } else {
        setItems([])
      }
    } catch (err) {
      console.error('Error resetting meals:', err)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card title="Registrar comida">
        <div className="space-y-2">
          <input
            className="w-full p-2 border rounded"
            placeholder="Nombre del alimento"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            className="w-full p-2 border rounded"
            placeholder="Calorías estimadas"
            value={calories}
            onChange={(e) => setCalories(e.target.value)}
            type="number"
          />
          <div className="flex gap-2">
            <Button onClick={add}>Agregar</Button>
            <Button onClick={resetDay} className="bg-red-600">
              Resetear día
            </Button>
          </div>
        </div>
      </Card>

      <Card title={`Comidas registradas (${items.length})`}>
        <div className="space-y-2">
          {items.length === 0 && <p>No hay comidas registradas.</p>}
          {items.map((it) => (
            <div key={it.id} className="flex justify-between items-center">
              <div>
                <div className="font-medium">{it.name}</div>
                <div className="text-sm text-gray-500">{it.calories} kcal</div>
              </div>
              <div>
                <button onClick={() => remove(it.id)} className="text-red-600">Eliminar</button>
              </div>
            </div>
          ))}

          <div className="mt-4 font-semibold">Total: {total} kcal</div>
          <div className="mt-2 flex gap-2">
            <button onClick={() => {
              // Crear tabla HTML para abrir en Excel
              const rows = items.map(i => `<tr><td>${i.name}</td><td>${i.calories}</td></tr>`).join('')
              const html = `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body><table><tr><th>Nombre</th><th>Calorías</th></tr>${rows}</table></body></html>`
              const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
              const url = URL.createObjectURL(blob)
              const a = document.createElement('a')
              a.href = url
              a.download = 'comidas.xls'
              a.click()
              URL.revokeObjectURL(url)
            }} className="btn-primary">
              Exportar a Excel
            </button>
          </div>
        </div>
      </Card>
    </div>
  )
}
