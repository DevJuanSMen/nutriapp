import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'
import Card from '../components/Card'
import Button from '../components/Button'

export default function Register() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  async function handleRegister(e) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const { data } = await api.post('/auth/register', { email, password })
      // Auto login
      localStorage.setItem('token', data.token)
      localStorage.setItem('user', JSON.stringify(data.user))

      // Create profile (optional, if backend doesn't do it automatically or if we want to add extra fields like name)
      // Note: My backend register currently only takes email/password. 
      // I should update the backend to accept name if needed, but for now let's just redirect.

      setLoading(false)
      navigate('/home')
    } catch (err) {
      setLoading(false)
      setError(err.response?.data?.error || 'Error al registrarse')
    }
  }

  return (
    <div className="max-w-md mx-auto mt-8">
      <Card title="Crear cuenta">
        <form onSubmit={handleRegister} className="space-y-3">
          <input className="w-full p-2 border rounded" placeholder="Nombre" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="w-full p-2 border rounded" placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="w-full p-2 border rounded" placeholder="Contraseña" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {error && <div className="text-red-600">{error}</div>}
          <div className="flex justify-end">
            <Button type="submit">{loading ? 'Creando...' : 'Crear cuenta'}</Button>
          </div>
        </form>
      </Card>
    </div>
  )
}
