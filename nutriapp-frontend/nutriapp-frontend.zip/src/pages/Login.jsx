import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'
import Card from '../components/Card'
import Button from '../components/Button'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  async function handleLogin(e) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const { data } = await api.post('/auth/login', { email, password })
      localStorage.setItem('token', data.token)
      localStorage.setItem('user', JSON.stringify(data.user))
      setLoading(false)
      navigate('/home')
    } catch (err) {
      setLoading(false)
      setError(err.response?.data?.error || 'Error al iniciar sesión')
    }
  }

  return (
    <div className="max-w-md mx-auto mt-8">
      <Card title="Iniciar sesión">
        <form onSubmit={handleLogin} className="space-y-3">
          <input className="w-full p-2 border rounded" placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="w-full p-2 border rounded" placeholder="Contraseña" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {error && <div className="text-red-600">{error}</div>}
          <div className="flex justify-end">
            <Button type="submit" className="">{loading ? 'Cargando...' : 'Entrar'}</Button>
          </div>
        </form>
      </Card>
    </div>
  )
}
