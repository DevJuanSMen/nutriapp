import React from 'react'
import { Navigate } from 'react-router-dom'

export default function ProtectedRoute({ children }) {
  const authenticated = Boolean(localStorage.getItem('token'))

  if (!authenticated) return <Navigate to="/login" replace />
  return children
}
