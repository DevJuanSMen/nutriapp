import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

export default function Navbar() {
  const [user, setUser] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    // Check for user in localStorage
    const token = localStorage.getItem('token')
    const userStr = localStorage.getItem('user')
    if (token && userStr) {
      try {
        setUser(JSON.parse(userStr))
      } catch (e) {
        console.error('Error parsing user:', e)
      }
    }
  }, [])

  function logout() {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
    navigate('/')
  }

  return (
    <header className="app-header">
      <div className="container mx-auto p-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-food-green flex items-center justify-center text-white font-bold">N</div>
          <h1 className="text-2xl font-semibold text-food-green">NutriApp</h1>
        </div>

        <nav className="space-x-4">
          <Link to="/home" className="text-gray-700 hover:text-food-green">Home</Link>
          <Link to="/calories" className="text-gray-700 hover:text-food-green">Registro</Link>
          {/* <Link to="/trans" className="text-gray-700 hover:text-food-green">Personas trans</Link> */}
          <Link to="/recipes" className="text-gray-700 hover:text-food-green">Recetario</Link>
          {!user ? (
            <>
              <Link to="/login" className="text-gray-700 hover:text-food-green">Entrar</Link>
              <Link to="/register" className="text-gray-700 hover:text-food-green">Crear cuenta</Link>
            </>
          ) : (
            <>
              <span className="text-gray-700">{user.email}</span>
              <button onClick={logout} className="text-sm text-red-600">Cerrar sesión</button>
            </>
          )}
        </nav>
      </div>
    </header>
  )
}
